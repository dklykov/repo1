<?php
class TaggingAppModel extends AppModel
{
	
}
?>