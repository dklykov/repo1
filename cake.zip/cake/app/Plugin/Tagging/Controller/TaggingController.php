<?php
class TaggingController extends TaggingAppController
{
	var $name = 'Tagging';
	
	var $uses = array();
	
	function admin_index()
	{
		
	}
}
?>