<?php
class TaggingAppController extends AppController
{
	var $helpers = array('Html', 'Form', 'Javascript');
}
?>