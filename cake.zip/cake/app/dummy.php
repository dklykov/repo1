<?php
exit();
//Add in some helpers so the code assist works much better.
if(false) {
	$ajax = new AjaxHelper();
	$form = new FormHelper();
	$html = new HtmlHelper();
	$javascript = new JavascriptHelper();
	$number = new NumberHelper();
	$session = new SessionHelper();
	$text = new TextHelper();
	$time = new TimeHelper();
	$pagination = new PaginationHelper();
	$rss = new RssHelper();
	$xml = new XmlHelper();
	$js = new JsHelper();
}
?>